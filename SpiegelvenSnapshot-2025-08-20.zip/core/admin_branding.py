from django.contrib import admin

# Tekst linksboven in de zwarte balk
admin.site.site_header = "Spiegelven Fakturatie"
# Tekst in de browsertitel
admin.site.site_title = "Spiegelven Fakturatie"
# Tekst op de startpagina van de admin
admin.site.index_title = "Beheer"
